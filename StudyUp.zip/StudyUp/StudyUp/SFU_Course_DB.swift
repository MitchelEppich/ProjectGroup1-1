//
//  SFU_Course_DB.swift
//  StudyUp
//
//  Created by Mitchel Eppich on 2017-03-07.
//  Copyright © 2017 SFU Health++. All rights reserved.
//

import Foundation


class SFU_Course_db {
    let course = [
        "ARCH",
        "BISC",
        "BUEC",
        "BUS",
        "CHEM",
        "CMNS",
        "CMNS",
        "CMPT",
        "CRIM",
        "EASC",
        "ECON",
        "EDUC",
        "ENGL",
        "ENSC",
        "EVSC",
        "EXPL",
        "FAN",
        "FPA",
        "FREN",
        "GEOG",
        "GSWS",
        "HIST",
        "HSCI",
        "HUM",
        "IAT",
        "IS",
        "ISPO",
        "KIN",
        "LING",
        "MATH",
        "MBB",
        "PERS",
        "PHIL",
        "PHYS",
        "POL",
        "PSYC",
        "SA",
        "SCI",
        "STAT",
        "TECH",
        "WL"
    ]

}
